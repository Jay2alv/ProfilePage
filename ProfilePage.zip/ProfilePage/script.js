function editname() {
    var h1 = document.querySelector(".name");
    h1.innerText = "Jessica Jones";
    console.log(h1)
}
function hide(){
    var element = document.querySelector(".toddreq")
    element.remove();
}
function hide1(){
    var element1 = document.querySelector(".philreq")
    element1.remove();
}
var requests = 2
function decrease(){
    var req = document.querySelector(".nmbr")
    requests--;
    req.innerText = requests;
}
var connections = 500
function increase(){
    var connect = document.querySelector(".nmbr2")
    connections++;
    connect.innerText = connections + "+"
}